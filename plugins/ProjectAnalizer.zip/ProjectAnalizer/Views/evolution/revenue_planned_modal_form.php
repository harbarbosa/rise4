<?php
$id = $model_info ? $model_info->id : 0;
echo form_open(get_uri("projectanalizer/revenue/save_planned"), array("id" => "revenue-planned-form", "class" => "general-form", "role" => "form"));
?>

<div class="modal-body clearfix">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    <input type="hidden" name="project_id" value="<?php echo $project_id; ?>">

    <div class="form-group">
        <label for="title"><?php echo app_lang("revenue_title"); ?></label>
        <?php
        echo form_input(array(
            "id" => "title",
            "name" => "title",
            "class" => "form-control",
            "value" => $model_info ? $model_info->title : "",
            "required" => true
        ));
        ?>
    </div>

    <div class="form-group">
        <label for="planned_date"><?php echo app_lang("planned_date"); ?></label>
        <?php
        echo form_input(array(
            "id" => "planned_date",
            "name" => "planned_date",
            "class" => "form-control",
            "value" => $model_info ? $model_info->planned_date : "",
            "autocomplete" => "off",
            "required" => true
        ));
        ?>
    </div>

    <div class="form-group">
        <label for="planned_value"><?php echo app_lang("planned_value"); ?></label>
        <?php
        echo form_input(array(
            "id" => "planned_value",
            "name" => "planned_value",
            "class" => "form-control",
            "value" => $model_info ? $model_info->planned_value : "",
            "required" => true
        ));
        ?>
    </div>

    <div class="form-group">
        <label for="percent_of_contract"><?php echo app_lang("percent_of_contract"); ?></label>
        <?php
        echo form_input(array(
            "id" => "percent_of_contract",
            "name" => "percent_of_contract",
            "class" => "form-control",
            "value" => $model_info ? $model_info->percent_of_contract : ""
        ));
        ?>
    </div>

    <div class="form-group">
        <label for="notes"><?php echo app_lang("notes"); ?></label>
        <?php
        echo form_textarea(array(
            "id" => "notes",
            "name" => "notes",
            "class" => "form-control",
            "value" => $model_info ? $model_info->notes : ""
        ));
        ?>
    </div>
</div>

<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app_lang("close"); ?></button>
    <button type="submit" class="btn btn-primary"><?php echo app_lang("save"); ?></button>
</div>

<?php echo form_close(); ?>

<script type="text/javascript">
    $(document).ready(function () {
        setDatePicker("#planned_date");
        $("#revenue-planned-form").appForm({
            onSuccess: function () {
                location.reload();
            }
        });
    });
</script>

