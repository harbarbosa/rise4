<?php

return [
    'os_menu_title' => 'Ordem de Serviço',
    'os_menu_list' => 'Ordens de Serviço',
    'os_menu_settings' => 'Configurações',
    'os_menu_types' => 'Tipos',
    'os_menu_reasons' => 'Motivos',
    'os_add_type' => 'Adicionar Tipo',
    'os_add_reason' => 'Adicionar Motivo',
    'os_edit_type' => 'Editar Tipo',
    'os_edit_reason' => 'Editar Motivo',
    'Serviços' => 'Serviços',
];

