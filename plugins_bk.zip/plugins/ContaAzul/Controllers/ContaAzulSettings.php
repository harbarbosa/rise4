<?php

namespace ContaAzul\Controllers;

use App\Controllers\Security_Controller;
use App\Models\Settings_model;
use App\Models\Clients_model;
use App\Models\Labels_model;
use App\Models\Items_model;
use ContaAzul\Libraries\ContaAzulClient;

class ContaAzulSettings extends Security_Controller
{
    public $Settings_model;
    public $Clients_model;
    public $Items_model;

    public function __construct()
    {
        parent::__construct();
        $this->access_only_admin();
        $this->Settings_model = new Settings_model();
        $this->Clients_model = new Clients_model();
        $this->Items_model = new Items_model();
    }

    public function index()
    {
        $redirect_uri = get_setting("contaazul_redirect_uri");
        if (!$redirect_uri) {
            $redirect_uri = get_uri("contaazul/callback");
        }

        $data = [
            "title" => "Conta Azul",
            "client_id" => get_setting("contaazul_client_id"),
            "client_secret" => get_setting("contaazul_client_secret"),
            "access_token" => get_setting("contaazul_access_token"),
            "refresh_token" => get_setting("contaazul_refresh_token"),
            "expires_at" => get_setting("contaazul_token_expires_at"),
            "cron_key" => get_setting("contaazul_cron_key"),
            "redirect_uri" => $redirect_uri,
            "scope" => get_setting("contaazul_scope") ?: "openid profile aws.cognito.signin.user.admin",
            "authorize_url" => get_uri("contaazul/authorize"),
            "logs" => $this->getLogs(20)
        ];

        return $this->template->rander('ContaAzul\Views\settings', $data);
    }

    public function save()
    {
        $redirect_uri = $this->request->getPost('redirect_uri') ?: get_uri("contaazul/callback");
        $scope = $this->request->getPost('scope') ?: "openid profile aws.cognito.signin.user.admin";

        $fields = [
            "contaazul_client_id" => $this->request->getPost('client_id'),
            "contaazul_client_secret" => $this->request->getPost('client_secret'),
            "contaazul_access_token" => $this->request->getPost('access_token'),
            "contaazul_refresh_token" => $this->request->getPost('refresh_token'),
            "contaazul_token_expires_at" => $this->request->getPost('expires_at'),
            "contaazul_cron_key" => $this->request->getPost('cron_key'),
            "contaazul_redirect_uri" => $redirect_uri,
            "contaazul_scope" => $scope,
        ];

        foreach ($fields as $name => $value) {
            $this->Settings_model->save_setting($name, $value);
        }

        $this->session->setFlashdata("success_message", "Configurações salvas.");
        return app_redirect('contaazul');
    }

    public function authorize()
    {
        $clientId = get_setting("contaazul_client_id");
        $clientSecret = get_setting("contaazul_client_secret");

        if (!$clientId || !$clientSecret) {
            $this->session->setFlashdata("error_message", "Preencha Client ID e Client Secret antes de conectar.");
            return app_redirect('contaazul');
        }

        $redirectUri = get_setting("contaazul_redirect_uri") ?: get_uri("contaazul/callback");
        $scope = get_setting("contaazul_scope") ?: "openid profile aws.cognito.signin.user.admin";

        $state = bin2hex(random_bytes(16));
        $this->session->set("contaazul_oauth_state", $state);

        $client = new ContaAzulClient($clientId, $clientSecret, $redirectUri, $scope);
        $authUrl = $client->getAuthorizationUrl($state);

        return redirect()->to($authUrl);
    }

    public function callback()
    {
        $code = $this->request->getGet('code');
        $state = $this->request->getGet('state');
        $savedState = $this->session->get("contaazul_oauth_state");

        if (!$code || !$state || !$savedState || $state !== $savedState) {
            $this->session->setFlashdata("error_message", "Autorizacao invalida. Tente novamente.");
            return app_redirect('contaazul');
        }

        $clientId = get_setting("contaazul_client_id");
        $clientSecret = get_setting("contaazul_client_secret");
        $redirectUri = get_setting("contaazul_redirect_uri") ?: get_uri("contaazul/callback");
        $scope = get_setting("contaazul_scope") ?: "openid profile aws.cognito.signin.user.admin";

        $client = new ContaAzulClient($clientId, $clientSecret, $redirectUri, $scope);
        $result = $client->exchangeCode($code);

        if (!$result["ok"]) {
            $this->session->setFlashdata("error_message", "Falha ao trocar token: " . $result["body"]);
            return app_redirect('contaazul');
        }

        $this->persistTokens($client->getTokens());
        $this->session->remove("contaazul_oauth_state");
        $this->session->setFlashdata("success_message", "Conta Azul conectada com sucesso.");

        return app_redirect('contaazul');
    }

    /**
     * Importa pessoas (clientes) usando access_token/refresh_token já informados.
     */
    public function import_clients()
    {
        $result = $this->runImport('manual');
        return $this->response->setJSON($result);
    }

    public function import_items()
    {
        $result = $this->runItemsImport('manual');
        return $this->response->setJSON($result);
    }

    /**
     * Endpoint para rodar via cron: GET contaazul/cron-import?key=...
     */
    public function cron_import()
    {
        $key = $this->request->getGet('key');
        $savedKey = get_setting('contaazul_cron_key');

        if (!$savedKey || $key !== $savedKey) {
            return $this->response->setJSON(["success" => false, "message" => "Acesso negado ao cron (key inválida)."]);
        }

        $result = $this->runImport('cron');
        return $this->response->setJSON($result);
    }

    /**
     * Reuso da importação para cron e UI.
     */
    private function runImport($source = 'manual')
    {
        // garante que estruturas mínimas existam (caso o install não tenha rodado)
        $this->ensureLogTable();
        $this->ensureContaAzulColumn();

        $client = $this->makeClient();
        if ($client->isExpired() && get_setting("contaazul_refresh_token")) {
            $refresh = $client->refreshAccessToken(get_setting("contaazul_refresh_token"));
            if ($refresh["ok"]) {
                $this->persistTokens($client->getTokens());
            } else {
                return ["success" => false, "message" => "Token expirado e falha ao renovar: {$refresh['body']}"];
            }
        }

        $page = 0;
        $size = 50;
        $imported = 0;
        $updated = 0;
        $suppliers_imported = 0;
        $suppliers_updated = 0;
        $transportadoras_imported = 0;
        $transportadoras_updated = 0;
        $errors = [];
        $processed = 0;

        $label_id = $this->getContaAzulLabelId();
        $suppliers_model = $this->getPurchasesSuppliersModel();
        $transportadoras_model = $this->getPurchasesTransportadorasModel();

        while (true) {
            $resp = $client->listPeople($page, $size);
            if (!$resp["ok"]) {
                return [
                    "success" => false,
                    "message" => "Falha ao consultar clientes (HTTP {$resp['status']}): {$resp['body']}"
                ];
            }

            $customers = $this->extractCustomers($resp["data"]);

            if (empty($customers)) {
                break;
            }

            $processed += count($customers);

            foreach ($customers as $customer) {
                $mapped = $this->mapCustomer($customer);
                if (!$mapped) {
                    continue;
                }

                $existing = null;
                if (!empty($mapped["vat_number"])) {
                    $existing = $this->Clients_model->get_one_where(["vat_number" => $mapped["vat_number"], "deleted" => 0]);
                }
                if (!$existing || !get_array_value((array)$existing, "id")) {
                    $existing = $this->Clients_model->get_one_where(["company_name" => $mapped["company_name"], "deleted" => 0]);
                }

                if ($label_id) {
                    $current_labels = $existing && isset($existing->labels) ? $existing->labels : "";
                    $mapped["labels"] = $this->mergeLabelId($current_labels, $label_id);
                }

                $mapped = clean_data($mapped);

                if ($existing && get_array_value((array)$existing, "id")) {
                    $save = $this->Clients_model->ci_save($mapped, $existing->id);
                    $updated += $save ? 1 : 0;
                    if (!$save) {
                        $dbErr = $this->Clients_model->db->error();
                        $errors[] = "Falha ao atualizar {$mapped['company_name']} (" . ($dbErr['message'] ?? 'erro desconhecido') . ")";
                    }
                } else {
                    $save = $this->Clients_model->ci_save($mapped);
                    $imported += $save ? 1 : 0;
                    if (!$save) {
                        $dbErr = $this->Clients_model->db->error();
                        $errors[] = "Falha ao inserir {$mapped['company_name']} (" . ($dbErr['message'] ?? 'erro desconhecido') . ")";
                    }
                }

                if ($suppliers_model && $this->hasContaAzulProfile($customer, "fornecedor")) {
                    $supplier_data = $this->mapSupplier($customer);
                    if ($supplier_data) {
                        $supplier_result = $this->saveSupplier($suppliers_model, $supplier_data);
                        if ($supplier_result === "updated") {
                            $suppliers_updated++;
                        } elseif ($supplier_result === "imported") {
                            $suppliers_imported++;
                        }
                    }
                }

                if ($transportadoras_model && $this->hasContaAzulProfile($customer, "transportadora")) {
                    $transportadora_data = $this->mapTransportadora($customer);
                    if ($transportadora_data) {
                        $transportadora_result = $this->saveTransportadora($transportadoras_model, $transportadora_data);
                        if ($transportadora_result === "updated") {
                            $transportadoras_updated++;
                        } elseif ($transportadora_result === "imported") {
                            $transportadoras_imported++;
                        }
                    }
                }
            }

            if (count($customers) < $size) {
                break;
            }
            $page++;
        }

        $this->saveLog($imported, $updated, $errors, $source, [
            "suppliers_imported" => $suppliers_imported,
            "suppliers_updated" => $suppliers_updated,
            "transportadoras_imported" => $transportadoras_imported,
            "transportadoras_updated" => $transportadoras_updated
        ]);

        return [
            "success" => true,
            "processed" => $processed,
            "imported" => $imported,
            "updated" => $updated,
            "suppliers_imported" => $suppliers_imported,
            "suppliers_updated" => $suppliers_updated,
            "transportadoras_imported" => $transportadoras_imported,
            "transportadoras_updated" => $transportadoras_updated,
            "errors" => $errors
        ];
    }

    private function runItemsImport($source = 'manual')
    {
        $this->ensureLogTable();

        $client = $this->makeClient();
        if ($client->isExpired() && get_setting("contaazul_refresh_token")) {
            $refresh = $client->refreshAccessToken(get_setting("contaazul_refresh_token"));
            if ($refresh["ok"]) {
                $this->persistTokens($client->getTokens());
            } else {
                return ["success" => false, "message" => "Token expirado e falha ao renovar: {$refresh['body']}"];
            }
        }

        $page = 0;
        $size = 50;
        $processed = 0;
        $imported = 0;
        $updated = 0;
        $errors = [];

        while (true) {
            $resp = $client->listProducts($page, $size);
            if (!$resp["ok"]) {
                return [
                    "success" => false,
                    "message" => "Falha ao consultar produtos (HTTP {$resp['status']}): {$resp['body']}"
                ];
            }

            $products = $this->extractCustomers($resp["data"]);
            if (empty($products)) {
                break;
            }

            $processed += count($products);

            foreach ($products as $product) {
                $mapped = $this->mapProduct($product);
                if (!$mapped) {
                    continue;
                }

                $items_table = $this->Items_model->db->prefixTable('items');
                $existing = $this->Items_model->db->table($items_table)
                    ->select("id")
                    ->where("deleted", 0)
                    ->where("title", $mapped["title"])
                    ->get()
                    ->getRow();
                $mapped = clean_data($mapped);

                if ($existing && get_array_value((array)$existing, "id")) {
                    $save = $this->Items_model->ci_save($mapped, $existing->id);
                    $updated += $save ? 1 : 0;
                    if (!$save) {
                        $dbErr = $this->Items_model->db->error();
                        $errors[] = "Falha ao atualizar {$mapped['title']} (" . ($dbErr['message'] ?? 'erro desconhecido') . ")";
                    }
                } else {
                    $save = $this->Items_model->ci_save($mapped);
                    $imported += $save ? 1 : 0;
                    if (!$save) {
                        $dbErr = $this->Items_model->db->error();
                        $errors[] = "Falha ao inserir {$mapped['title']} (" . ($dbErr['message'] ?? 'erro desconhecido') . ")";
                    }
                }
            }

            if (count($products) < $size) {
                break;
            }

            $page++;
        }

        $this->saveLog($imported, $updated, $errors, $source, [
            "items_imported" => $imported,
            "items_updated" => $updated
        ]);

        return [
            "success" => true,
            "processed" => $processed,
            "imported" => $imported,
            "updated" => $updated,
            "errors" => $errors
        ];
    }

    /**
     * Salva log da execução.
     */
    private function saveLog($imported, $updated, $errors, $source = 'manual', $meta = [])
    {
        $db = db_connect('default');
        $table = get_db_prefix() . 'contaazul_logs';
        if (!$db->tableExists($table)) {
            return;
        }
        $builder = $db->table($table);
        try {
            $builder->insert([
                'run_at' => date('Y-m-d H:i:s'),
                'source' => $source ?: 'manual',
                'imported' => $imported,
                'updated' => $updated,
                'errors' => $errors ? json_encode($errors) : null,
                'meta' => $meta ? json_encode($meta) : null
            ]);
        } catch (\Exception $ex) {
            log_message('error', 'ContaAzul log insert failed: {exception}', ['exception' => $ex]);
        }
    }

    /**
     * Recupera histórico (limit).
     */
    private function getLogs($limit = 20)
    {
        $db = db_connect('default');
        $table = get_db_prefix() . 'contaazul_logs';

        // se tabela não existir (instalação antiga), retorna lista vazia
        if (!$db->tableExists($table)) {
            return [];
        }

        try {
            $builder = $db->table($table);
            $query = $builder->orderBy('run_at', 'DESC')->limit($limit)->get();
            return $query ? $query->getResult() : [];
        } catch (\Exception $ex) {
            return [];
        }
    }

    /**
     * Cria a coluna id_conta_azul em clients se não existir.
     */
    private function ensureContaAzulColumn()
    {
        $db = db_connect('default');
        $clientsTable = get_db_prefix() . 'clients';
        $colId = $db->query("SHOW COLUMNS FROM `{$clientsTable}` LIKE 'id_conta_azul'")->getResult();
        if (empty($colId)) {
            $db->query("ALTER TABLE `{$clientsTable}` ADD COLUMN `id_conta_azul` VARCHAR(100) NULL DEFAULT NULL");
        }
        // Código interno (id_legado) retornado pelo Conta Azul para a pessoa
        $colCodigo = $db->query("SHOW COLUMNS FROM `{$clientsTable}` LIKE 'codigo_conta_azul'")->getResult();
        if (empty($colCodigo)) {
            $db->query("ALTER TABLE `{$clientsTable}` ADD COLUMN `codigo_conta_azul` VARCHAR(100) NULL DEFAULT NULL");
        }
    }

    /**
     * Cria a tabela de logs, se não existir, e adiciona coluna source.
     */
    private function ensureLogTable()
    {
        $db = db_connect('default');
        $prefix = get_db_prefix();
        $table = $prefix . 'contaazul_logs';
        if ($db->tableExists($table)) {
            $col = $db->query("SHOW COLUMNS FROM `{$table}` LIKE 'source'")->getResult();
            if (empty($col)) {
                $db->query("ALTER TABLE `{$table}` ADD COLUMN `source` VARCHAR(20) NOT NULL DEFAULT 'manual' AFTER `run_at`");
            }
            $col_meta = $db->query("SHOW COLUMNS FROM `{$table}` LIKE 'meta'")->getResult();
            if (empty($col_meta)) {
                $db->query("ALTER TABLE `{$table}` ADD COLUMN `meta` TEXT NULL AFTER `updated`");
            }
            return;
        }

        $sql = "CREATE TABLE IF NOT EXISTS `{$table}` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `run_at` DATETIME NOT NULL,
            `source` VARCHAR(20) NOT NULL DEFAULT 'manual',
            `imported` INT NOT NULL DEFAULT 0,
            `updated` INT NOT NULL DEFAULT 0,
            `errors` TEXT NULL,
            `meta` TEXT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;";
        $db->query($sql);
    }

    private function makeClient($data = null)
    {
        $cfg = $data ?: [
            "client_id" => get_setting("contaazul_client_id"),
            "client_secret" => get_setting("contaazul_client_secret"),
            "redirect_uri" => get_setting("contaazul_redirect_uri"),
            "scope" => get_setting("contaazul_scope"),
            "access_token" => get_setting("contaazul_access_token"),
            "refresh_token" => get_setting("contaazul_refresh_token"),
            "expires_at" => get_setting("contaazul_token_expires_at"),
        ];

        return new ContaAzulClient(
            $cfg["client_id"],
            $cfg["client_secret"],
            $cfg["redirect_uri"],
            $cfg["scope"],
            $cfg["access_token"],
            $cfg["refresh_token"],
            $cfg["expires_at"]
        );
    }

    private function persistTokens($tokens)
    {
        $this->Settings_model->save_setting("contaazul_access_token", $tokens["access_token"]);
        $this->Settings_model->save_setting("contaazul_refresh_token", $tokens["refresh_token"]);
        $this->Settings_model->save_setting("contaazul_token_expires_at", $tokens["expires_at"]);
    }

    private function extractCustomers($payload)
    {
        if (!$payload) {
            return [];
        }

        if (isset($payload["items"]) && is_array($payload["items"])) {
            return $payload["items"];
        }

        if (isset($payload["_embedded"]["customers"])) return $payload["_embedded"]["customers"];
        if (isset($payload["content"])) return $payload["content"];
        if (is_array($payload) && isset($payload[0])) return $payload;
        return [];
    }

    private function mapCustomer($customer)
    {
        if (!is_array($customer)) return null;

        $name = get_array_value($customer, "nome") ?? get_array_value($customer, "business_name") ?? get_array_value($customer, "name");
        if (!$name) return null;

        $taxNumber = get_array_value($customer, "documento") ??
            get_array_value($customer, "federalTaxNumber") ??
            get_array_value($customer, "federal_tax_number") ??
            get_array_value($customer, "cpf_cnpj") ??
            get_array_value($customer, "tax_id") ?? "";

        $personType = strtolower(get_array_value($customer, "tipo_pessoa", "juridica"));
        $type = in_array($personType, ["fisica", "natural", "pf", "person"]) ? "person" : "organization";

        $now = get_current_utc_time();
        $contaAzulId = get_array_value($customer, "id", "");
        $contaAzulCodigo = get_array_value($customer, "id_legado", "");

        return [
            "company_name" => $name,
            "type" => $type,
            "address" => "",
            "city" => "",
            "state" => "",
            "zip" => "",
            "country" => "",
            "created_date" => $now,
            "website" => "",
            "phone" => get_array_value($customer, "telefone", get_array_value($customer, "business_phone", get_array_value($customer, "mobile_phone", ""))),
            "currency_symbol" => "",
            "starred_by" => "",
            "group_ids" => "",
            "deleted" => 0,
            "is_lead" => 0,
            "lead_status_id" => 0,
            "owner_id" => $this->login_user ? $this->login_user->id : 1,
            "created_by" => $this->login_user ? $this->login_user->id : 1,
            "sort" => 0,
            "lead_source_id" => 0,
            "last_lead_status" => "",
            "client_migration_date" => date("Y-m-d"),
            "vat_number" => $taxNumber,
            "gst_number" => "",
            "stripe_customer_id" => "",
            "stripe_card_ending_digit" => 0,
            "currency" => "",
            "disable_online_payment" => 0,
            "labels" => "",
            "managers" => "",
            "id_conta_azul" => $contaAzulId,
            "codigo_conta_azul" => $contaAzulCodigo
        ];
    }

    private function hasContaAzulProfile($customer, $profileType)
    {
        if (!is_array($customer)) {
            return false;
        }

        $profiles = get_array_value($customer, "perfis");
        if (!is_array($profiles)) {
            return false;
        }

        foreach ($profiles as $profile) {
            $type = strtolower(get_array_value((array)$profile, "tipo_perfil", ""));
            if ($type === strtolower($profileType)) {
                return true;
            }
        }

        return false;
    }

    private function mapSupplier($customer)
    {
        if (!is_array($customer)) {
            return null;
        }

        $name = get_array_value($customer, "nome") ?? get_array_value($customer, "business_name") ?? get_array_value($customer, "name");
        if (!$name) {
            return null;
        }

        $taxNumber = get_array_value($customer, "documento") ??
            get_array_value($customer, "federalTaxNumber") ??
            get_array_value($customer, "federal_tax_number") ??
            get_array_value($customer, "cpf_cnpj") ??
            get_array_value($customer, "tax_id") ?? "";

        $address_parts = array_filter([
            get_array_value($customer, "endereco") ?? get_array_value($customer, "address"),
            get_array_value($customer, "bairro"),
            get_array_value($customer, "cidade") ?? get_array_value($customer, "city"),
            get_array_value($customer, "estado") ?? get_array_value($customer, "state"),
            get_array_value($customer, "cep") ?? get_array_value($customer, "zip")
        ]);

        return [
            "company_id" => 0,
            "name" => $name,
            "email" => get_array_value($customer, "email") ?? "",
            "phone" => get_array_value($customer, "telefone", get_array_value($customer, "business_phone", get_array_value($customer, "mobile_phone", ""))),
            "tax_id" => $taxNumber,
            "address" => $address_parts ? implode(" - ", $address_parts) : "",
            "created_at" => get_current_utc_time(),
            "created_by" => $this->login_user ? $this->login_user->id : 1,
            "updated_at" => get_current_utc_time(),
            "deleted" => 0
        ];
    }

    private function mapProduct($product)
    {
        if (!is_array($product)) {
            return null;
        }

        $title = get_array_value($product, "nome") ??
            get_array_value($product, "name") ??
            get_array_value($product, "descricao") ??
            get_array_value($product, "description");

        $title = trim((string)$title);
        if (!$title) {
            return null;
        }

        $description = get_array_value($product, "descricao") ??
            get_array_value($product, "description") ??
            "";

        $unit = get_array_value($product, "unidade") ??
            get_array_value($product, "unit") ??
            "";

        $cost = get_array_value($product, "custo") ??
            get_array_value($product, "preco_custo") ??
            get_array_value($product, "cost") ??
            get_array_value($product, "cost_price");

        $rate = get_array_value($product, "valor") ??
            get_array_value($product, "preco_venda") ??
            get_array_value($product, "sale_price") ??
            get_array_value($product, "price") ??
            0;

        if (is_numeric($cost)) {
            $rate = (float)$cost;
        } else {
            $rate = is_numeric($rate) ? (float)$rate : 0;
        }

        $taxable = get_array_value($product, "tributavel");
        if ($taxable === null) {
            $taxable = get_array_value($product, "taxable", 0);
        }
        $taxable = $taxable ? 1 : 0;

        return [
            "title" => $title,
            "description" => $description,
            "unit_type" => $unit,
            "rate" => $rate,
            "files" => "",
            "show_in_client_portal" => 0,
            "category_id" => 1,
            "taxable" => $taxable,
            "sort" => 0,
            "deleted" => 0
        ];
    }

    private function mapTransportadora($customer)
    {
        return $this->mapSupplier($customer);
    }

    private function saveSupplier($suppliers_model, $supplier_data)
    {
        $db = db_connect('default');
        $table = $db->prefixTable('purchases_suppliers');

        $existing_id = 0;
        if (!empty($supplier_data["tax_id"])) {
            $row = $db->table($table)
                ->select("id")
                ->where("deleted", 0)
                ->where("tax_id", $supplier_data["tax_id"])
                ->get()
                ->getRow();
            $existing_id = $row ? (int)$row->id : 0;
        }

        if (!$existing_id) {
            $row = $db->table($table)
                ->select("id")
                ->where("deleted", 0)
                ->where("name", $supplier_data["name"])
                ->get()
                ->getRow();
            $existing_id = $row ? (int)$row->id : 0;
        }

        $data = $supplier_data;
        if ($existing_id) {
            $suppliers_model->ci_save($data, $existing_id);
            return "updated";
        } else {
            $suppliers_model->ci_save($data);
            return "imported";
        }
    }

    private function saveTransportadora($transportadoras_model, $transportadora_data)
    {
        $db = db_connect('default');
        $table = $db->prefixTable('purchases_transportadoras');

        $existing_id = 0;
        if (!empty($transportadora_data["tax_id"])) {
            $row = $db->table($table)
                ->select("id")
                ->where("deleted", 0)
                ->where("tax_id", $transportadora_data["tax_id"])
                ->get()
                ->getRow();
            $existing_id = $row ? (int)$row->id : 0;
        }

        if (!$existing_id) {
            $row = $db->table($table)
                ->select("id")
                ->where("deleted", 0)
                ->where("name", $transportadora_data["name"])
                ->get()
                ->getRow();
            $existing_id = $row ? (int)$row->id : 0;
        }

        $data = $transportadora_data;
        if ($existing_id) {
            $transportadoras_model->ci_save($data, $existing_id);
            return "updated";
        } else {
            $transportadoras_model->ci_save($data);
            return "imported";
        }
    }

    private function getPurchasesSuppliersModel()
    {
        $purchases_path = PLUGINPATH . "Purchases";
        if (!is_dir($purchases_path)) {
            return null;
        }

        if (!class_exists("\\Purchases\\Models\\Purchases_suppliers_model")) {
            return null;
        }

        $db = db_connect('default');
        $table = $db->prefixTable('purchases_suppliers');
        if (!$db->tableExists($table)) {
            return null;
        }

        return model('Purchases\\Models\\Purchases_suppliers_model');
    }

    private function getPurchasesTransportadorasModel()
    {
        $purchases_path = PLUGINPATH . "Purchases";
        if (!is_dir($purchases_path)) {
            return null;
        }

        if (!class_exists("\\Purchases\\Models\\Purchases_transportadoras_model")) {
            return null;
        }

        $db = db_connect('default');
        $table = $db->prefixTable('purchases_transportadoras');
        if (!$db->tableExists($table)) {
            return null;
        }

        return model('Purchases\\Models\\Purchases_transportadoras_model');
    }

    private function getContaAzulLabelId()
    {
        $Labels_model = new Labels_model();
        $label = $Labels_model->get_one_where([
            "title" => "CA",
            "context" => "client",
            "deleted" => 0
        ]);

        if ($label && get_array_value((array)$label, "id")) {
            return $label->id;
        }

        $label_data = [
            "title" => "CA",
            "color" => "#1f78d1",
            "context" => "client",
            "user_id" => 0,
            "sort" => 0
        ];

        return $Labels_model->ci_save($label_data);
    }

    private function mergeLabelId($labels, $label_id)
    {
        if (!$label_id) {
            return $labels;
        }

        $labels = trim((string)$labels);
        if ($labels === "") {
            return (string)$label_id;
        }

        $list = array_filter(array_map('trim', explode(',', $labels)));
        if (!in_array((string)$label_id, $list, true)) {
            $list[] = (string)$label_id;
        }

        return implode(',', $list);
    }
}
