<?php

namespace Config;

$routes = Services::routes();

$routes->get('contaazul', 'ContaAzulSettings::index', ['namespace' => 'ContaAzul\Controllers']);
$routes->get('contaazul/authorize', 'ContaAzulSettings::authorize', ['namespace' => 'ContaAzul\Controllers']);
$routes->get('contaazul/callback', 'ContaAzulSettings::callback', ['namespace' => 'ContaAzul\Controllers']);
$routes->post('contaazul/save', 'ContaAzulSettings::save', ['namespace' => 'ContaAzul\Controllers']);
$routes->post('contaazul/import-clients', 'ContaAzulSettings::import_clients', ['namespace' => 'ContaAzul\Controllers']);
$routes->post('contaazul/import-items', 'ContaAzulSettings::import_items', ['namespace' => 'ContaAzul\Controllers']);
$routes->get('contaazul/cron-import', 'ContaAzulSettings::cron_import', ['namespace' => 'ContaAzul\Controllers']);
