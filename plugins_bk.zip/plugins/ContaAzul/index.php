<?php

defined('PLUGINPATH') or exit('No direct script access allowed');

/*
  Plugin Name: ContaAzul
  Description: Integração Conta Azul com OAuth2 (Authorization Code) e importação de clientes.
  Version: 0.1.0
  Requires at least: 3.0
 */

if (!defined('CONTA_AZUL_MODULE_NAME')) {
    define('CONTA_AZUL_MODULE_NAME', 'ContaAzul');
}

// adiciona item no menu de configurações (Plugins)
app_hooks()->add_filter('app_filter_admin_settings_menu', function ($settings_menu) {
    $settings_menu["plugins"][] = array("name" => "contaazul", "url" => "contaazul");
    return $settings_menu;
});

// Exportacao desativada: este plugin apenas importa clientes do Conta Azul.

// hook de instalação
register_installation_hook(CONTA_AZUL_MODULE_NAME, function () {
    require_once __DIR__ . '/install.php';
});
