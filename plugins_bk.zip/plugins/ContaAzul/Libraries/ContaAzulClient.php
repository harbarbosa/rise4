<?php

namespace ContaAzul\Libraries;

class ContaAzulClient
{
    const AUTH_URL = 'https://auth.contaazul.com/login';
    const TOKEN_URL = 'https://auth.contaazul.com/oauth2/token';
    const API_BASE = 'https://api-v2.contaazul.com';

    private $clientId;
    private $clientSecret;
    private $redirectUri;
    private $scope;
    private $accessToken;
    private $refreshToken;
    private $expiresAt;

    public function __construct($clientId, $clientSecret, $redirectUri, $scope = 'openid profile aws.cognito.signin.user.admin', $accessToken = '', $refreshToken = '', $expiresAt = '')
    {
        $this->clientId = $clientId;
        $this->clientSecret = $clientSecret;
        $this->redirectUri = $redirectUri;
        $this->scope = $scope;
        $this->accessToken = $accessToken;
        $this->refreshToken = $refreshToken;
        $this->expiresAt = $expiresAt;
    }

    public function getAuthorizationUrl($state)
    {
        $params = http_build_query([
            'response_type' => 'code',
            'client_id' => $this->clientId,
            'redirect_uri' => $this->redirectUri,
            'state' => $state,
            'scope' => $this->scope
        ]);
        return self::AUTH_URL . '?' . $params;
    }

    public function exchangeCode($code)
    {
        $body = http_build_query([
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $this->redirectUri
        ]);

        return $this->tokenRequest($body);
    }

    public function refreshAccessToken($refreshToken = null)
    {
        $refresh = $refreshToken ?: $this->refreshToken;
        if (!$refresh) {
            return ["ok" => false, "status" => 0, "data" => null, "body" => "Refresh token vazio"];
        }

        $body = http_build_query([
            'grant_type' => 'refresh_token',
            'refresh_token' => $refresh
        ]);

        return $this->tokenRequest($body);
    }

    public function listPeople($page = 0, $size = 50)
    {
        $page = max(0, (int) $page);
        $size = max(1, (int) $size);
        $query = http_build_query([
            'pagina' => $page,
            'tamanho_pagina' => $size
        ]);
        $url = self::API_BASE . '/v1/pessoas?' . $query;
        $headers = [
            'Authorization: Bearer ' . $this->accessToken,
            'Content-Type: application/json'
        ];

        return $this->getRequest($url, $headers);
    }

    public function listProducts($page = 0, $size = 50)
    {
        $page = max(0, (int) $page);
        $size = max(1, (int) $size);
        $query = http_build_query([
            'pagina' => $page,
            'tamanho_pagina' => $size
        ]);
        $url = self::API_BASE . '/v1/produtos?' . $query;
        $headers = [
            'Authorization: Bearer ' . $this->accessToken,
            'Content-Type: application/json'
        ];

        return $this->getRequest($url, $headers);
    }

    public function isExpired()
    {
        if (!$this->expiresAt) {
            return true;
        }
        $ts = is_numeric($this->expiresAt) ? (int) $this->expiresAt : strtotime($this->expiresAt);
        return $ts <= (time() + 300);
    }

    public function setTokensFromResponse($data)
    {
        $this->accessToken = $data['access_token'] ?? '';
        $this->refreshToken = $data['refresh_token'] ?? $this->refreshToken;
        $this->expiresAt = isset($data['expires_in']) ? time() + (int)$data['expires_in'] : $this->expiresAt;
    }

    public function getTokens()
    {
        return [
            'access_token' => $this->accessToken,
            'refresh_token' => $this->refreshToken,
            'expires_at' => $this->expiresAt
        ];
    }

    private function tokenRequest($body)
    {
        $headers = [
            "Authorization: Basic " . base64_encode($this->clientId . ":" . $this->clientSecret),
            "Content-Type: application/x-www-form-urlencoded"
        ];

        $ch = curl_init(self::TOKEN_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        $this->applyCaInfo($ch);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ["ok" => false, "status" => 0, "data" => null, "body" => $error];
        }

        $decoded = json_decode($response, true);
        $ok = $httpCode >= 200 && $httpCode < 300 && isset($decoded['access_token']);
        if ($ok) {
            $this->setTokensFromResponse($decoded);
        }

        return ["ok" => $ok, "status" => $httpCode, "data" => $decoded, "body" => $response];
    }

    private function getRequest($url, $headers)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        $this->applyCaInfo($ch);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ["ok" => false, "status" => 0, "data" => null, "body" => $error];
        }

        $decoded = json_decode($response, true);

       

        
       
        $ok = $httpCode >= 200 && $httpCode < 300;
        return ["ok" => $ok, "status" => $httpCode, "data" => $decoded, "body" => $response];
    }

    /**
     * Cria pessoa/cliente no Conta Azul.
     */
    public function createPerson($data)
    {
        $url = self::API_BASE . '/v1/pessoas';
        $headers = [
            'Authorization: Bearer ' . $this->accessToken,
            'Content-Type: application/json'
        ];

        return $this->postJson($url, $data, $headers);
    }

    /**
     * Atualiza pessoa/cliente no Conta Azul.
     */
    public function updatePerson($id, $data)
    {
        $url = self::API_BASE . '/v1/pessoas/' . $id;
        $headers = [
            'Authorization: Bearer ' . $this->accessToken,
            'Content-Type: application/json'
        ];

        return $this->putJson($url, $data, $headers);
    }

    /**
     * Exclui pessoa/cliente no Conta Azul.
     */
    public function deletePerson($id)
    {
        $url = self::API_BASE . '/v1/pessoas/' . $id;
        $headers = [
            'Authorization: Bearer ' . $this->accessToken,
            'Content-Type: application/json'
        ];

        return $this->deleteRequest($url, $headers);
    }

    private function postJson($url, $data, $headers)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        $this->applyCaInfo($ch);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ["ok" => false, "status" => 0, "data" => null, "body" => $error];
        }

        $decoded = json_decode($response, true);
        $ok = $httpCode >= 200 && $httpCode < 300;
        return ["ok" => $ok, "status" => $httpCode, "data" => $decoded, "body" => $response];
    }

    private function putJson($url, $data, $headers)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PATCH");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        $this->applyCaInfo($ch);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ["ok" => false, "status" => 0, "data" => null, "body" => $error];
        }

        $decoded = json_decode($response, true);
        $ok = $httpCode >= 200 && $httpCode < 300;
        return ["ok" => $ok, "status" => $httpCode, "data" => $decoded, "body" => $response];
    }

    private function deleteRequest($url, $headers)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        $this->applyCaInfo($ch);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ["ok" => false, "status" => 0, "data" => null, "body" => $error];
        }

        $decoded = json_decode($response, true);
        $ok = $httpCode >= 200 && $httpCode < 300;
        return ["ok" => $ok, "status" => $httpCode, "data" => $decoded, "body" => $response];
    }

    private function applyCaInfo($ch)
    {
        $ca = ini_get('curl.cainfo');
        if (!$ca) {
            $ca = ini_get('openssl.cafile');
        }
        if ($ca && is_file($ca)) {
            curl_setopt($ch, CURLOPT_CAINFO, $ca);
            return;
        }

        $fallbacks = [
            'C:\\laragon\\bin\\php\\php-8.1.10-Win32-vs16-x64\\extras\\ssl\\cacert.pem',
            'C:\\laragon\\bin\\php\\php-8.2.12-Win32-vs16-x64\\extras\\ssl\\cacert.pem',
            'C:\\laragon\\bin\\php\\php-8.3.0-Win32-vs16-x64\\extras\\ssl\\cacert.pem',
            'C:\\laragon\\etc\\ssl\\cacert.pem',
            'D:\\Projects\\Laragon-installer\\8.0-W64\\etc\\ssl\\cacert.pem',
            'D:\\Projects\\Laragon-installer\\8.0-W64\\extras\\ssl\\cacert.pem',
        ];

        foreach ($fallbacks as $path) {
            if (is_file($path)) {
                curl_setopt($ch, CURLOPT_CAINFO, $path);
                return;
            }
        }
    }
}
